#!/bin/bash
# setup.sh — One-time setup for the SDN Pipeline on your laptop
# Run this ONCE after copying the package to your laptop.

set -e
echo "============================================"
echo "  SDN Pipeline — Local Setup"
echo "============================================"

cd "$(dirname "$0")"

# Create virtual environment
if [ ! -d ".venv" ]; then
    echo "[1/3] Creating Python virtual environment..."
    python3 -m venv .venv
else
    echo "[1/3] Virtual environment already exists"
fi

# Activate and install dependencies
echo "[2/3] Installing dependencies..."
source .venv/bin/activate
pip install --upgrade pip -q
pip install -r requirements.txt -q 2>&1 | tail -3

# Try installing ryu (optional, may fail on Python > 3.10)
echo "[3/3] Installing Ryu OpenFlow controller (optional)..."
pip install ryu -q 2>/dev/null && echo "  ✅ Ryu installed" || echo "  ⚠️  Ryu failed (Python > 3.10?) — port mirroring mode will be used"

echo ""
echo "============================================"
echo "  ✅ Setup complete!"
echo ""
echo "  Activate:  source .venv/bin/activate"
echo "  Run:       bash run.sh --interface <NIC>"
echo "  Guide:     cat LiveTraffic/ARUBA_2920_LIVE_TESTING_GUIDE.md"
echo "============================================"
