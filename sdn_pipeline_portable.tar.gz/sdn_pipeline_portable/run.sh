#!/bin/bash
# run.sh — Start the SDN Pipeline for live traffic capture
#
# Usage:
#   bash run.sh --interface eth0              # Passive capture (port mirroring)
#   bash run.sh --interface eth0 --openflow   # Active OpenFlow mode
#   bash run.sh --demo                        # Demo mode (no hardware)
#
# Prerequisites:
#   1. Run setup.sh first
#   2. Connect Ethernet to switch port 24
#   3. Set static IP: sudo ip addr add 10.0.0.1/24 dev eth0

set -e
cd "$(dirname "$0")"
source .venv/bin/activate

INTERFACE="eth0"
DURATION=300
MODE="live"
OPENFLOW=""
LOG_DIR="logs"

# Parse args
while [[ $# -gt 0 ]]; do
    case "$1" in
        --interface|-i) INTERFACE="$2"; shift 2 ;;
        --duration|-d) DURATION="$2"; shift 2 ;;
        --openflow) OPENFLOW="yes"; shift ;;
        --demo) MODE="demo"; shift ;;
        --help|-h)
            echo "Usage: bash run.sh [--interface NIC] [--duration SECS] [--openflow] [--demo]"
            exit 0 ;;
        *) shift ;;
    esac
done

mkdir -p "$LOG_DIR"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)

echo "============================================"
echo "  SDN Zero-Trust Pipeline"
echo "============================================"
echo "  Mode:      $MODE"
echo "  Interface: $INTERFACE"
echo "  Duration:  ${DURATION}s"
echo "  OpenFlow:  ${OPENFLOW:-no}"
echo "  Log:       $LOG_DIR/pipeline_${TIMESTAMP}.json"
echo "============================================"

if [ "$MODE" = "demo" ]; then
    echo ""
    echo "Starting demo mode (synthetic flows, no hardware needed)..."
    python LiveTraffic/live_pipeline.py \
        --demo \
        --duration "$DURATION" \
        --ddl_model models/ddl_40feat.pkl \
        --log_path "$LOG_DIR/demo_${TIMESTAMP}.json"
    exit 0
fi

# Set up network interface
echo ""
echo "Setting up $INTERFACE..."
sudo ip link set "$INTERFACE" up 2>/dev/null || true
sudo ip link set "$INTERFACE" promisc on 2>/dev/null || true

# Quick connectivity test
echo "Testing capture on $INTERFACE..."
PKTS=$(sudo timeout 3 tcpdump -i "$INTERFACE" -c 5 -q 2>/dev/null | wc -l || echo "0")
if [ "$PKTS" -gt 0 ]; then
    echo "  ✅ Seeing traffic on $INTERFACE"
else
    echo "  ⚠️  No traffic on $INTERFACE (switch may not be configured yet)"
fi

if [ -n "$OPENFLOW" ]; then
    echo ""
    echo "Starting OpenFlow controller in background..."
    python LiveTraffic/openflow_controller.py --cmd_port 6634 &
    OF_PID=$!
    sleep 2
    echo "  Controller PID: $OF_PID"
    
    echo "Starting pipeline with OpenFlow DROP enforcement..."
    python LiveTraffic/live_pipeline.py \
        --interface "$INTERFACE" \
        --duration "$DURATION" \
        --ddl_model models/ddl_40feat.pkl \
        --openflow_host 127.0.0.1 \
        --openflow_port 6634 \
        --log_path "$LOG_DIR/openflow_${TIMESTAMP}.json"
    
    kill $OF_PID 2>/dev/null
else
    echo ""
    echo "Starting pipeline (passive capture)..."
    sudo python LiveTraffic/live_pipeline.py \
        --interface "$INTERFACE" \
        --duration "$DURATION" \
        --ddl_model models/ddl_40feat.pkl \
        --log_path "$LOG_DIR/pipeline_${TIMESTAMP}.json"
fi

echo ""
echo "============================================"
echo "  Pipeline finished!"
echo "  Results: $LOG_DIR/"
echo "============================================"
