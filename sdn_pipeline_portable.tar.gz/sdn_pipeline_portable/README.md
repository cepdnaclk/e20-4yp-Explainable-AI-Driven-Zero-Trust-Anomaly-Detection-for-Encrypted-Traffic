# SDN Zero-Trust Pipeline — Portable Package

## Quick Start (3 commands)

```bash
# 1. Setup (one-time)
bash setup.sh

# 2. Connect Ethernet to switch Port 24, then:
sudo ip addr add 10.0.0.1/24 dev eth0
sudo ip link set eth0 up

# 3. Run
bash run.sh --interface eth0 --duration 300
```

## Demo (no hardware)
```bash
bash setup.sh
bash run.sh --demo
```

## Files
```
models/                     ← Pre-trained models (DO NOT modify)
  sentry_model_v2.pkl       ← BCC Stage 1 (28 features, Decision Tree)
  ddl_40feat.pkl            ← DDL Stage 2 (40 features, Dictionary Learning)
  isolation_forest.pkl      ← IF Stage 2 (40 features)
DDLModel/                   ← DDL model code + 40-feature extractor
sdn/extraction/             ← Sandaru's 28-feature extractor
LiveTraffic/                ← Pipeline + controller + traffic generator
  live_pipeline.py          ← Main pipeline (NFStream capture → classify)
  openflow_controller.py    ← Ryu OpenFlow 1.3 controller
  traffic_generator.py      ← Scapy-based traffic generator
  ARUBA_2920_LIVE_TESTING_GUIDE.md  ← Full switch setup guide
setup.sh                    ← One-time dependency installer
run.sh                      ← Pipeline launcher
generate_traffic.sh         ← Traffic generator shortcut
```

## Network Topology
```
WiFi ─── SSH to remote server (keeps your connection alive)
eth0 ─── Switch Port 24 (10.0.0.1/24) ← traffic capture

Host A (Port 1, 10.0.0.2) ←→ Switch ←→ Host B (Port 2, 10.0.0.3)
                                ↕
                    SDN Laptop (Port 24, 10.0.0.1)
```
