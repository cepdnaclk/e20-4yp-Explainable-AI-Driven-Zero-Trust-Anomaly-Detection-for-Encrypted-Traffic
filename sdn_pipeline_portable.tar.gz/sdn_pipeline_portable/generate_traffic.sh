#!/bin/bash
# generate_traffic.sh — Generate test traffic on the switch network
#
# Run this from Host A (10.0.0.2) to send traffic through the switch.
#
# Usage:
#   bash generate_traffic.sh normal    # Benign HTTP/DNS traffic
#   bash generate_traffic.sh attack    # SYN flood + port scan
#   bash generate_traffic.sh mixed     # Both simultaneously

set -e
cd "$(dirname "$0")"

MODE="${1:-mixed}"
TARGET="${2:-10.0.0.3}"

echo "Traffic mode: $MODE → Target: $TARGET"

case "$MODE" in
    normal)
        echo "Generating benign traffic..."
        for i in $(seq 1 50); do
            curl -s -m 2 -o /dev/null http://$TARGET/ 2>/dev/null &
            sleep 0.$((RANDOM % 5 + 1))
        done
        wait
        ;;
    attack)
        echo "Generating attack traffic (requires sudo)..."
        # SYN flood for 10 seconds
        echo "  [1/3] SYN flood..."
        sudo timeout 10 hping3 -S --flood -p 80 $TARGET 2>/dev/null &
        sleep 12
        
        # Port scan
        echo "  [2/3] Port scan..."
        sudo nmap -sS -p 1-100 $TARGET 2>/dev/null &
        sleep 15
        
        # Our scapy generator
        echo "  [3/3] Scapy attack flows..."
        source .venv/bin/activate 2>/dev/null || true
        sudo python LiveTraffic/traffic_generator.py --mode attack --count 5 --interface eth0
        ;;
    mixed)
        echo "Generating mixed traffic (benign background + attacks)..."
        # Background benign
        for i in $(seq 1 100); do
            curl -s -m 2 -o /dev/null http://$TARGET/ 2>/dev/null &
            sleep 0.3
        done &
        BENIGN_PID=$!
        
        sleep 10
        echo "  Starting attacks..."
        sudo timeout 15 hping3 -S --flood -p 80 $TARGET 2>/dev/null &
        sleep 20
        sudo nmap -sS -p 1-50 $TARGET 2>/dev/null
        
        kill $BENIGN_PID 2>/dev/null
        ;;
    *)
        echo "Usage: bash generate_traffic.sh [normal|attack|mixed] [target_ip]"
        ;;
esac

echo "Traffic generation complete."
